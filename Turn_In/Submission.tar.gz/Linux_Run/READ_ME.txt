All you have to do is run the bash script (run.sh)
To do that, do the following:

1.Type: ./run.sh

FYI I did not submit the data files as we were supposed to. If you need them, just put the following files in the the "Data_Files" folder:
1. data.eval.anon
2. data.eval.id
3. data.test
4. data.test.id
5. data.train
6. data.train.id
7. tweets.txt

Also my code for the following algorithms are in the following folder inside the "Code" folder:

1. Dynamic Learning Rate - Folder: "Aggressive_DynamicLearningRate_SVM_LR"
2. Aggressive Perceptron - Folder: "Aggressive_DynamicLearningRate_SVM_LR"
3. SVM - Folder: "Aggressive_DynamicLearningRate_SVM_LR"
4. Logistic Regression - Folder: "Aggressive_DynamicLearningRate_SVM_LR"
5. Bagged Forest - Folder: "Bagged_Forest"
6. Decision Tree - Folder: "Decision_Tree"
